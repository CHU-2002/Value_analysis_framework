# 独立盲样运行证据

预标注见 `docs/verification/req017-blind-annotations.md`；该文件先于模型运行冻结，不按输出调整优先级。两份原始官方PDF的完整下载地址、sha256和页数在sources.json，沙箱原件仍在 `output/.live_req017_eval/`，未写使用者真实存档。

此目录归档源清单副本、失败日志、模型候选及综合/排除记录和独立门禁输出。清单中的相对PDF路径以原始沙箱为基准；不要将归档目录误作下载目的地。复现时从仓库根运行：

```bash
.venv/bin/python docs/run-records/2026-10-15-REQ-017/independent/prepare_sources.py
cp docs/run-records/2026-10-15-REQ-017/independent/blind_a_materials.json output/.live_req017_eval/
cp docs/run-records/2026-10-15-REQ-017/independent/blind_b_materials.json output/.live_req017_eval/
```

原件应重新核对sources.json中的sha256；官方材料更新或网络不可达时如实记录，不自动换样本。运行的模型、传输、日期与失败原因见独立验收报告和问题记录。所有模型结果均为待核对输出，未因“有JSON产物”便自动认定验收通过。

原始日志逐字节封装于raw_logs.zip（含CLI错误的空白行），不对原始输出做格式修剪；同目录.log仅为本地展开副本。停止时完整盲样响应另见stopped_blind_run4_run5_checkpoints.zip。
