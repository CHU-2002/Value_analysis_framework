from pathlib import Path
import requests,hashlib,json,pdfplumber
root=Path('output/.live_req017_eval')
urls={'blind_a':'https://static.cninfo.com.cn/finalpage/2025-03-31/1222974700.PDF','blind_b':'https://dataclouds.cninfo.com.cn/shgonggao/2025/2025-05-07/18362e972a6511f0b58dfa163e957f7a.pdf'}
m={}
for key,url in urls.items():
 r=requests.get(url,timeout=60);r.raise_for_status();p=root/(key+'.pdf');p.write_bytes(r.content)
 with pdfplumber.open(p) as pdf:
  pages=[page.extract_text() or '' for page in pdf.pages]
 (root/(key+'.txt')).write_text('\n\n'.join('### PDF PAGE '+str(i+1)+'\n'+t for i,t in enumerate(pages)))
 m[key]={'url':url,'sha256':hashlib.sha256(r.content).hexdigest(),'pages':len(pages)}
(root/'sources.json').write_text(json.dumps(m,indent=2))
print(json.dumps(m))
