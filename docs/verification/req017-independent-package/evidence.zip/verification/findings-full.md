# REQ-017 独立验收问题记录

评估者 `/root/independent_evaluation` 未参与实现、提示词或实现测试设计。仅核查、运行及记录；不改产品代码。本记录不构成全部AC验收通过。

## E1：否定违法定性的中性说明被误当确证定性

- 观察基线：2026-10-15 首轮实现（HEAD c5ebd7c 上未提交改动），`citation_errors`。
- 复现：构造普通会计差错更正公告，引用原文含“本次公告披露收入确认会计差错更正，不构成对财务造假或信息披露违法的认定”，候选 explanation 为“本次仅为会计差错更正，不能认定为财务造假。”，status=company_explanation。
- 实际：返回 `['造假没有可对应的权威原始认定及机关/状态/行为，不得作确定性定性']`。
- 影响：本来符合 AC-5 的中性限定句，会被降为无法核实；没有区分“对来源作准确法律定性”和“提醒不能推断违法”。不需要监管来源来证明一个公告未包含造假认定。
- 复现命令：

```bash
.venv/bin/python - <<'PY'
from scripts.results.financial_events import citation_errors
m={'documents':[{'id':'doc','period':'2024FY','date':'2025-04-01','kind':'announcement'}], 'pages':{'doc:1':{'document_id':'doc','text':'公司本次公告披露收入确认会计差错更正，不构成对财务造假或信息披露违法的认定。'}}}
e={'period':'2024FY','disclosed_at':'2025-04-01','title':'收入确认差错更正','explanation':'本次仅为会计差错更正，不能认定为财务造假。','amount':'未披露','impact':'尚未核实','status':'company_explanation','references':[{'page_id':'doc:1','quote':m['pages']['doc:1']['text']}]}
print(citation_errors(e,m))
PY
```

状态：已向实现方反馈；待修复后独立复验。

### E1 首轮修复复验

2026-10-15 同一最小复现重新执行，`citation_errors` 返回 `[]`；该中性限定句不再因无监管原件而被误判。提示词未变。最终是否能正确处理真实更正材料仍以真实样例输出核查为准。

## E2 / T4：真实模型默认配置不可用，首轮盲样无法运行完成

- 2026-10-15 两份独立盲样均启动真实流程：

```bash
.venv/bin/python -m scripts.results.financial_events --materials output/.live_req017_eval/blind_a_materials.json --output-dir output/.live_req017_eval/blind_a_run1 --workers 3
.venv/bin/python -m scripts.results.financial_events --materials output/.live_req017_eval/blind_b_materials.json --output-dir output/.live_req017_eval/blind_b_run1 --workers 3
```

- 官方完整报告分别328/301页，提取及哈希核对成功；两个运行均未产出任何 reading、review、audit 或最终报告，入口进程最终返回1。
- 实现方独立诊断默认CLI模型在当前账号不支持（已登记T4），通知停止默认模型调用；独立评估方尝试发送中断时，两个进程均已完成并返回1。没有把失败包装成成功，没有重用旧报告。
- 首轮日志原样保存在 `output/.live_req017_eval/blind_{a,b}_run1.log`，不包含token；材料与冻结预标注均保留。
- 结论：首轮 AC-1…3/8 真实盲样未验成。待产品前置模型校验与可用模型确认后，使用相同材料重跑；不改变盲样或验收标准，不改全局配置。

## 盲态独立性检查

2026-10-15 独立扫描 `scripts/results/**`、`shared/qualitative/**` 和 `docs/FINANCIAL_REPORT_EVENTS_PLAN.md` 的Python/Markdown/JSON文件，未发现两家盲样公司名称。预标注文件哈希未变；材料未用来设计生产规则或提示词。现阶段实跑阻断来自默认CLI模型不可用，而非更换盲样。

## 通用可靠性修复独立复验

- 直接创建 `CodexModel()`：在模型启动前抛出ValueError，明确CLI默认模型已知不兼容、需显式选目录模型，不自动替换。
- `CodexModel(model='not-a-real-model')`：同样在调用前拒绝非法目录组合。
- 以临时合成 `investment.report_events` 验证 `load_events`：run_state为running、failed、complete但结果摘要错误时全部拒绝；只有complete且result_digest与原始payload一致才接受。
- 以上不读取token、不联网、不改实现；验证的是入口预检与旧产物关闭行为，不能替代真实模型发现能力验收。

## E3：官方更正/监管样例 run2 未形成可发布事项

独立读取 `output/.live_req017/wuliangye-r2/major_events.md`：没有完成原文复核的重大结论，两个候选均降级，因此 AC-7 尚不通过。

- 更正候选因 `doc.period == event.period` 精确字符串比较被本地判为无主证据。多期公告的元数据组合期间，与模型写法语义相符也可能字面不符；不能靠调整事实使字符串相等，应使用能严格表达所涉期次且允许一致格式的通用核对方式。
- 监管决定原文涉及2000—2009多项披露，材料元数据仅写2007—2009；audit据此正确拒绝。应修正来源元数据，不能改audit结果。
- 监管候选引用不能逐字对应原文，或没有覆盖其中若干重要数字；本地及模型回查均拒绝。需要重新生成引用充分的候选。
- 更正审计还指出未纳入历史决定的原页，无法独立审计其与当前事件关系。将跨文献关系写成候选结论时，需要把相关原文也作为对应证据纳入审计。

已向实现方反馈；没有修改材料、实现或审核结果。待修复重跑。

## 修复前独立全量门禁（非最终收口）

```bash
make verify > output/.live_req017_eval/independent_verify.log 2>&1
```

- 独立执行退出0；1989 passed, 3 skipped；覆盖率76.68%（门槛74%）；用例总数1992、50支文件（预算2000/52）。追溯单独18 passed；回归门禁通过。
- 3个skip均为未配置TUSHARE_TOKEN的既有真实API用例，未增加skip。
- 运行前源码SHA256：financial_events.py=`22ae075a82b9ab6949d9b9e076817b2183a0a205b21e63ee0d988c368eeedf3a`；提示文档=`3ca491512815c5bc75cbcf8e2b934e3a2176784d8599e0c8dd7976d240d89227`。
- 该轮在E3/T8修复前，不能替代最终稳定版门禁。没有把“测试全绿”当成真实样例AC通过。

## E4：真实完整盲样run2在输出语义校验阶段失败

第二轮显式指定可用模型与官方HTTPS传输，不改变冻结材料：

```bash
.venv/bin/python -m scripts.results.financial_events --materials output/.live_req017_eval/blind_a_materials.json --output-dir output/.live_req017_eval/blind_a_run2 --model gpt-6-luna --transport https --workers 3
.venv/bin/python -m scripts.results.financial_events --materials output/.live_req017_eval/blind_b_materials.json --output-dir output/.live_req017_eval/blind_b_run2 --model gpt-6-luna --transport https --workers 3
```

- A：所有9个read包保存成功，模型确实广泛提出47项候选；review保存16项入选与31项排除，但有原始candidate ID未被覆盖，抛 `ValueError: review silently omitted candidates; no report published`。数量对上不代表ID逐个追溯正确，护栏拒绝合理。
- B：有一个read包的候选disclosed_at并非ISO日期，而是在日期后附括号解释；`date.fromisoformat`抛ValueError。其余read包已留档，整体未产生review/最终报告。
- 两进程均退出1，run_state=failed，未发布报告。不能以已产生候选宣称AC-8通过。
- 可审阅性缺口：read响应在形状验证后才写盘，B中形状无效的原始模型响应未保存。需要先保存原始响应，再以通用repair流程修复并重新验证，不得删掉严格校验或静默改模型答案。
- 此问题与公司名无关，反馈实现方只描述通用日期/ID/留档问题；未泄露冻结线索。需要修复后相同材料重跑。

### E4 留档修复独立复验

2026-10-15，纯虚构公司/单页、fake model返回disclosed_at=`2025-05-07（错误附注）`：入口依旧抛ValueError，`reading-001.json`已保留完整原始响应，run_state=failed，report_events.json不存在。证据目录 `output/.live_req017_eval/invalid_date_retention`。证明保留错误材料而未放宽校验；真实模型ISO schema约束另由run3验证。

第三轮真实盲样保持相同材料，仅显式改为 `--model gpt-6-sol --transport https --workers 3`，目录为blind_a_run3 / blind_b_run3。模型变更、通用repair与语义校验修复均由实现方在盲态完成，没有根据盲样线索定制。

## 2026-10-17 恢复后的既有结果复核

- 第三轮真实盲样均失败：A完成读包后review调用“模型连接超时”；B已进入audit后模型运行失败。原始日志、已产出的read/review/audit等JSON归档在独立证据目录，未用失败轮次宣称AC-8通过。
- 对0132f1f的独立最终门禁当时执行完成：1989 passed, 3 skipped，76.70%，50文件/1992用例，追溯18 passed，回归门禁绿。此次仍属新resume修复之前的基线，不替代后续稳定实现验证。
- 官方wuliangye-r4更正事项修复后通过原文审核；历史处罚第二轮模型审核verified，但本地连续引文法律标签护栏仍拒绝。原文的“信息披露存在以下违法事实”“重大遗漏”“未按照规定披露信息的违法行为”，与标题笼统标签“信息披露违法”并非连续同句逐字对应。应使用原文准确法律定性并重新审查，而非删掉本地错误或直接改审核结果。监管材料behavior元数据仍含“高管薪酬披露”，但原文为高管被调查未及时披露，亦须据原文校正。
- 已只向实现方反馈通用引用/repair/元数据问题，未透露盲样公司或重大线索；等待通用缓存resume修复稳定后以相同冻结材料继续。

### 2026-10-17 e64f449 严格断点恢复独立复验

纯虚构材料与本地fake model模拟read完成后review中断：首次调用read/review，resume仅调用review，证明已完成read未重跑。改材料、改模型身份、旧目录无指纹三者均拒绝；原始缓存response被篡改且未改摘要时拒绝。结果在resume_observations.json；无真实模型费用。未采用旧run3无指纹产物，run4使用相同原件重新运行。

独立worktree不含.venv，普通make verify先在解释器入口失败（尚未跑测试）；使用Makefile既有公开参数PYTHON指向原仓同一解释器继续全门禁，无产品/环境文件修改。

### E3 后续官方样例独立核查（wuliangye-r5）

更正事项与2011历史处罚均已进入重大事项区，各自日期/期间分开、原始来源可点击、公司解释/监管认定/分析推断区分清楚。更正分别给出Q1/H1/Q3原列报→重述后收入与利润、税前/税后/归母口径、累计数不能相加、不影响现金流量表列示的公司说明和年度盈亏/净资产限制。处罚保留重大遗漏、披露不及时不完整及录入差错未及时更正等原有定性，列机关、公司、历史行为与金额；后续复议诉讼执行状态未知，并明确不得挪用于2025更正或推定造假。独立对照原件及各次audit：更正一次verified；处罚初次引用漏字被拦，repair后连续引文核对通过并重新audit verified，local_errors为空；原始失败及修订均保留。AC-5、AC-7及该样例的AC-8/9成立，整体验收仍待伊利与两盲样。

### 0017ad4最终独立门禁与M6复核

在独立worktree执行 `make verify PYTHON=/Users/everett.li/Project/Turtle_investment_framework/.venv/bin/python`，退出0：1988 passed, 5 skipped，76.68%覆盖率，50支文件/1993用例，追溯18 passed、回归门禁通过。5个skip为3个既有TUSHARE真实API与2个既有“worktree未放本地真实中报PDF”可选用例，未增skip；具体输出已归档。

独立审阅0017ad4：并发历史测试原目标是对同一快照做12线程写入，后台running→finished跨时刻比较是无关的竞态。复用既有wait_history_finished先等待终态落盘，再保留全部12线程、JSON/id/status/无残留/唯一临时名断言，属于公平固定前置条件；生命周期和重启仍由原有用例覆盖。没有放宽门禁或删断言。

## E5：包含比较期的同份报表被期间护栏误拒

对0017ad4的纯虚构数据独立复现：

```python
from scripts.results.financial_events import citation_errors
text='虚构公司2026年半年度合并利润表，单位人民币元：2026H1收入200，2025H1收入100。'
m={'documents':[{'id':'doc','period':'2026H1','date':'2026-08-20','kind':'report'}],'pages':{'doc:1':{'document_id':'doc','text':text}}}
e={'period':'2026H1/2025H1','disclosed_at':'2026-08-20','title':'两期收入比较','explanation':'本报告同时列示2026H1与2025H1合并收入。','amount':'200元与100元','impact':'收入同比增长100%；不推断原因。','status':'disclosed','references':[{'page_id':'doc:1','quote':text}]}
print(citation_errors(e,m))
```

实际返回“事项期间/披露日没有对应的主证据；历史事项须单独处理”。原文同时明确包含两期数据，而护栏只以doc主报告期作全集，拒绝合法比较期。伊利r4真实候选“收入增长、归母利润下降与经营现金流上升”“合并所得税费用上升、净利润下降”等也受此拒绝；不能将这种程序源范围错误当作合理未知/排除。属于AC-2跨期复核与AC-8完整线索呈现的实际缺口。实现方只收到通用复现与官方示例，未获知盲样公司或线索。

伊利r4本身成功退出、219页全读、5verified/11unverified/13excluded；AC-6所要求的合并减值2,455,875,173.02元、商誉减值1,546,544,866.49元、澳优/存货解释与税前/归母限制均准确显著，AC-6通过。其他事项的真实材料局限与程序误拒必须分别处理，整体REQ-017暂不能verified。

### E5修复与严格donor迁移独立复验（70331a2）

同一E5纯虚构复现现返回空错误列表，比较期不再因doc主期标签而误拒；并保留原文与审核要求。donor本地测试：同请求迁移fake模型0调用、全部响应留origin；材料/模型/提示/分包预算任一变更拒绝，原响应摘要不符拒绝。真实run5从冻结run4迁移14个read包及3个review响应，新增结构页使audit请求改变，早期新增audit响应均无origin，证明未用旧审核直接判通过。

run4按协调指令中断退出130，已有全部read/review及部分audit/repair响应留档，未手改run_state或审核结果；不把中断产物当发布报告。run5在相同冻结材料基础上只重做新输入审核，预标注未改变。

## E6：跨事件依赖可能使已核验事项丢失必需术语解释

独立检查官方yili-r5中间审核：主减值事项candidate001已verified，但术语只解释资产减值及现金流加回，说明“商誉和存货事项另列”；商誉子事项candidate002最终仍unverified，未在可发布事项中提供日常商誉解释。若最终报告保持该状态，AC-6将不通过，不能沿用yili-r4的旧通过结论。应由最终实际报告核验，不因单个candidate审核verified自动满足跨事项表达要求。允许通用有界repair增加尝试不等于降低审核标准，仍须保留失败链并重新audit。

### E6最终正文复核（yili-r6）

独立实际阅读最终major_events，不照搬模型plain_language=true。数字、归因与税前/归母边界仍准确，商誉子事项也已发布；但术语仍以“收购价款超过可辨认净资产价值”解释商誉，以“调低账面价值”解释商誉减值，未直接面向无需会计前置知识的读者串明“收购形成的预期价值被判断无法收回而确认费用”。AC-4/AC-6这部分暂不打勾。此处为最终读者解释的通用缺口，不得通过降低AC或只信模型审核消除；事实及证据链不要求推倒重做，最终输出需实际补足该含义后复核。
